package com.bmpl.game.player;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.bmpl.game.utils.Constants;

public class Ken extends CommonPlayer implements Constants {
	private BufferedImage idleImages[] = new BufferedImage[4];
	private BufferedImage walkImages[] = new BufferedImage[5];
	
	public Ken() throws IOException {
		x = SCREENWIDTH - 700;
		w = 300;
		h = 400;
		y = GROUND - h;
		speed = SPEED;
		imageIndex = 0;
		currentMove = IDLE;	// player in IDLE state
		playerImg = ImageIO.read(Ryu.class.getResource("ken_flip.png"));
		loadIdleImages();
		loadWalkImages();
	}
	
	private void loadIdleImages() {
		idleImages[0] = playerImg.getSubimage(670, 246, 119, 242);
		idleImages[1] = playerImg.getSubimage(892, 246, 115, 242);
		idleImages[2] = playerImg.getSubimage(1114, 246, 117, 242);
		idleImages[3] = playerImg.getSubimage(1345, 246, 117, 242);
	}
	
	public BufferedImage showIdle() {
		if(imageIndex > 3) {
			imageIndex = 0;
		}
		BufferedImage img = idleImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	private void loadWalkImages() {
//		walkImages[0] = playerImg.getSubimage(76, 128, 63, 92);
//		walkImages[1] = playerImg.getSubimage(151, 128, 67, 92);
//		walkImages[2] = playerImg.getSubimage(228, 128, 65, 92);
//		walkImages[3] = playerImg.getSubimage(303, 127, 59, 93);
//		walkImages[4] = playerImg.getSubimage(368, 127, 56, 93);
	}
	
	public BufferedImage showWalk() {
		if(imageIndex > 4) {
			imageIndex = 0;
			currentMove = IDLE;
		}
		BufferedImage img = walkImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	
	public BufferedImage defaultImage() {
		if(currentMove == WALK) {
			return showWalk();
		}
		else {
			return showIdle();
		}
		
	}
}
